<?php get_header(); ?>
<div id="posts">
<h2>Nothing found</h2>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>