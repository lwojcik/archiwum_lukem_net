</div><div id="footer"><p>Powered by <a href="http://lukem.net/portfolio/">Blogimalistic</a> by <a href="http://lukem.net/">Łukasz "Lukem" Wójcik</a>.</p></div>
<?php wp_footer(); ?>
</body>
</html>
